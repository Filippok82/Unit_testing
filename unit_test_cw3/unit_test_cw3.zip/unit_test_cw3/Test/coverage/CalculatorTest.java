package coverage;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;




import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {
    private Calculator calculator;

    @BeforeEach
    void setUps() {
        calculator = new Calculator();
    }

    @Test
    void RegularDiscount() {
        assertThat(calculator.calculatingDiscount(2000, 50)).isEqualTo(1000); // обычная скидка
        assertThat(calculator.calculatingDiscount(2000, 100)).isEqualTo(0); // обычная скидка
        assertThat(calculator.calculatingDiscount(2000, 0)).isEqualTo(2000); // обычная скидка

    }
//    assertThatThrownBy(() ->
//            Calculator.calculatingDiscount(2000, 110))
//            .isInstanceOf(ArithmeticException.class)
//                .hasMessage("Скидка должна быть от 0 до 100%"); // процент скидки больше 100%
//
//    assertThatThrownBy(() ->
//            Calculator.calculatingDiscount(2000, -10))
//            .isInstanceOf(ArithmeticException.class)
//                .hasMessage("Скидка должна быть от 0 до 100%"); // процент скидки меньше 0
//
//    assertThatThrownBy(() ->
//            Calculator.calculatingDiscount(-2000, 10))
//            .isInstanceOf(ArithmeticException.class)
//                .hasMessage("Скидка не может быть отрицательной"); // процент скидки меньше 0
//}
}