package coverage;
import static org.assertj.core.api.Assertions.*;
public class Calculator {
    public static double calculatingDiscount(double purchaseAmount, int discountAmount) {
        // purchaseAmount - сумма покупки
        // discountAmount - размер скидки
        double total_sum = 0; // сумма со скидкой
        if (purchaseAmount >= 0) {

            if (discountAmount >= 0 && discountAmount <= 100) {
                total_sum = purchaseAmount - (purchaseAmount * discountAmount) / 100;
            } else {
                throw new ArithmeticException("Скидка должна быть от 0 до 100%");
            }
        } else {
            throw new ArithmeticException("Скидка не может быть отрицательной");
        }


        return total_sum;


    }
}
